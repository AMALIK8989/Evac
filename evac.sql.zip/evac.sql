-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2024 at 07:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evac`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Error reading structure for table evac.admin: #1932 - Table 'evac.admin' doesn't exist in engine
-- Error reading data for table evac.admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `evac`.`admin`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `child`
--
-- Error reading structure for table evac.child: #1932 - Table 'evac.child' doesn't exist in engine
-- Error reading data for table evac.child: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `evac`.`child`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `hospital_list`
--
-- Error reading structure for table evac.hospital_list: #1932 - Table 'evac.hospital_list' doesn't exist in engine
-- Error reading data for table evac.hospital_list: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `evac`.`hospital_list`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `parent`
--
-- Error reading structure for table evac.parent: #1932 - Table 'evac.parent' doesn't exist in engine
-- Error reading data for table evac.parent: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `evac`.`parent`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `vaccination`
--
-- Error reading structure for table evac.vaccination: #1932 - Table 'evac.vaccination' doesn't exist in engine
-- Error reading data for table evac.vaccination: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `evac`.`vaccination`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `vaccination_list`
--
-- Error reading structure for table evac.vaccination_list: #1932 - Table 'evac.vaccination_list' doesn't exist in engine
-- Error reading data for table evac.vaccination_list: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `evac`.`vaccination_list`' at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
